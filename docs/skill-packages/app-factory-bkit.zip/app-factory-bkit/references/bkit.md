# bkit Reference

Use this when the task needs PDCA, quality gates, automation levels, lifecycle
hooks, context engineering, agent teams, or skill evaluation discipline.

## Essential Concepts

### Context Engineering

Context engineering is systematic design of what the agent sees, when it sees
it, and why. It combines:

- domain knowledge
- behavioral rules
- state management
- dynamic intent routing
- tool/session lifecycle hooks
- quality and audit feedback loops

### PDCA State Machine

Use a compact PDCA model:

```text
plan -> do -> check -> act -> report
```

Recommended mapping:

- `plan`: clarify spec, scope, impact, acceptance criteria.
- `do`: implement or produce the smallest useful artifact.
- `check`: run tests, checks, review, schema validation, or evals.
- `act`: integrate, update docs/state, choose the next slice.
- `report`: summarize outcome and next best move.

### Automation Levels

```text
manual    = all actions require approval
guided    = read/inspect freely, ask before writes
semi_auto = non-destructive checks and scoped edits allowed
auto      = continue only when already authorized by the task flow
```

Use lower automation when the action is destructive, external, expensive,
security-sensitive, or ambiguous.

### Quality Gates

Name the gate each recommendation satisfies:

- `scope`: affected surfaces and acceptance criteria are understood.
- `quality`: targeted validation has passed or is the next action.
- `security`: dangerous operations, secrets, permissions, or external effects
  are reviewed.
- `docs`: docs, plans, and implementation remain synchronized.
- `release`: broad validation before publish, push, deploy, or handoff.

### Hooks

Useful hook points:

- session start
- prompt submit
- before tool use
- after tool use
- after tool failure
- before compaction
- after compaction
- subagent start/stop
- session end

Do not inject large context into a running conversation if it breaks prompt
caching. Prefer out-of-band recommendations and persisted state.

### Agent Teams

Use teams only when parallel work is actually useful. Common roles:

- CTO/lead: decomposition and tradeoffs
- PM: requirements and product fit
- architect: system boundaries
- implementation worker: scoped patch
- QA/security: verification and risk review

Keep ownership disjoint when multiple workers edit code.

### Skill Evals

Treat skills as testable artifacts:

- workflow skills should be regression-tested
- capability skills should be parity-tested against newer models
- deprecated skills should have a removal reason
- eval prompts and expected outputs should live with the skill
