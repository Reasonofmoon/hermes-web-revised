# Hermes Adaptation Reference

Use this when applying App Factory + bkit ideas inside Hermes or another agent
codebase with tools, skills, sessions, and gateway surfaces.

## Mapping

| App Factory / bkit | Hermes Equivalent |
|---|---|
| module manifest | tool schema, command def, skill frontmatter, workflow node |
| envelope | trajectory record, session DB row, tool call record |
| catalog | tool registry, command registry, skill list |
| registry | pricing catalog, safety rules, provider registry, standards packs |
| PDCA state | development workflow phase |
| hook lifecycle | tool callbacks, CLI commands, gateway events, session persistence |
| quality gate | pytest, py_compile, lint, schema validation, security review |
| next action engine | `agent.next_best_move` or `/next` command |

## First-Class Workflow Nodes

Good first candidates:

- pricing normalization
- billing route resolution
- cost estimation
- usage persistence
- OpenRouter generation reconciliation
- tool registry changes
- slash command registry changes
- gateway adapter changes

Each node should declare:

- id
- input and output shape
- affected files
- focused tests
- quality gate
- next best move

## Recommendation Rules

Rules should be deterministic before learned:

```text
agent/usage_pricing.py changed
-> run pricing + context token tests

tools/registry.py changed
-> run registry + model_tools tests

gateway/ changed
-> run gateway tests

docs/plans/ changed
-> update the next implementation slice
```

## State Storage

Use profile-safe state:

```python
from hermes_constants import get_hermes_home
state_dir = get_hermes_home() / "workflow"
```

Do not write to hardcoded `~/.hermes`.

## Prompt Caching Guardrail

Never mutate past context or rebuild system prompts mid-conversation just to
inject workflow intelligence. Emit recommendations out-of-band:

- CLI `/next`
- gateway `/next`
- final response footer
- session-end summary
- persisted workflow state

## Embedding, RAG, And Graph Indexes

Use this section when someone asks whether RAG requires embeddings.

Short answer:

```text
RAG does not require embeddings.
Embeddings are one retrieval strategy.
```

RAG means:

```text
retrieve relevant external context -> assemble it -> give it to the model
```

The retrieval layer can be implemented with:

- vector search from embeddings
- BM25 or full-text search
- graph traversal
- structured metadata filters
- dependency/call graph analysis
- hybrid ranking across several of these signals

### Zilliz / Claude Context

`zilliztech/claude-context` is an embedding-first codebase retrieval system.

Typical flow:

```text
codebase
-> file discovery
-> AST-aware chunking
-> embedding generation
-> Milvus/Zilliz vector DB
-> BM25 + dense vector hybrid search
-> MCP search tools for the coding agent
```

Use it as the example for:

- vector database backed code search
- dense embedding search
- BM25 + vector hybrid retrieval
- MCP exposure of `index_codebase`, `search_code`, indexing status, and clear
  index operations

It is not the example for embedding-free RAG. It is the example for scalable
semantic code search.

### Graphify

`safishamsi/graphify` is the contrast case. It turns code, docs, and mixed
assets into a queryable knowledge graph.

Typical flow:

```text
code/docs/media
-> entity extraction
-> relation extraction
-> nodes and edges
-> graph report / graph JSON / graph UI
-> graph traversal or GraphRAG-style retrieval
```

Use it as the example for:

- relationship-first retrieval
- architecture exploration
- "what depends on what" questions
- mixed code and documentation understanding

Graphify may still use semantic techniques, but the central artifact is the
graph, not a plain vector index.

### App Factory + bkit Position

For this skill, use a layered vocabulary:

```text
Index Layer
  - vector chunks
  - graph nodes and edges
  - manifests
  - envelopes
  - workflow state

Retrieval Layer
  - vector search
  - BM25/FTS
  - graph traversal
  - schema and metadata filters

Context Assembly Layer
  - selected snippets
  - provenance
  - confidence
  - quality gate
  - next best move

Agent Runtime Layer
  - model receives only the assembled context it needs
```

Recommended answer:

```text
Embedding 없는 RAG는 가능합니다. 다만 vector semantic search를 쓰지 않는
RAG입니다. BM25/FTS, knowledge graph, manifest metadata, dependency graph를
조합해 retrieval을 만들고, 그 결과를 context로 조립하면 됩니다. Zilliz의
claude-context는 embedding + vector DB + BM25 hybrid 방식이고, Graphify는
관계 그래프 중심 방식입니다.
```

## Final Response Pattern

Use this compact footer:

```text
Next best move: run `/next` or run the focused test command.
Reason: it closes the quality gate for the changed surface.
Gate: quality
Automation: semi_auto
Risk: low
```
