# App Factory Reference

Use this when the task needs reproducible module workflows, app-spec generation,
envelopes, catalogs, or learned path suggestions.

## Essential Concepts

### Module Manifest

A module is a workflow unit with a stable contract.

```yaml
id: jtbd
version: 1.0.0
phase: L0
title: Jobs-to-be-Done Interviewer
description: Discover and structure the user's core job.

contracts:
  input_schema: ./input.schema.json
  output_schema: ./output.schema.json
  downstream:
    - persona
    - valueprop

budget:
  tokens_in_max: 4000
  tokens_out_max: 2000
  recommended_model: claude-sonnet

quality_bar:
  min_score: 7.0
  required_sections: [core_job, outcomes, context, constraints]
```

### Envelope

Every execution should preserve enough information to reproduce or audit it:

- module id, version, hash
- model provider, model id, parameters
- input hash and payload
- output hash and payload
- parent envelope ids
- validation result
- metrics: tokens, cost, latency, cache hit
- next-path intelligence

### Catalog And Registry

- **Catalog**: available modules and their metadata.
- **Registry**: reusable standards, rule packs, compliance references, design
  systems, security controls, or external source packs.

### Hebbian Path Engine

Record transitions:

```text
from_module -> to_module
```

Strengthen transitions that lead to useful, validated outcomes. Weaken paths
that fail validation, are heavily edited, or are rejected by the user.

Start deterministic. Learn only after the static rules are useful.

## Practical Use

When applying App Factory to another codebase:

1. Identify the repeatable workflow steps.
2. Give each step a manifest-like identity.
3. Define input/output contracts.
4. Save provenance for each execution.
5. Add a next-best-move recommendation after each step.
6. Add learning only after static recommendations are trusted.
