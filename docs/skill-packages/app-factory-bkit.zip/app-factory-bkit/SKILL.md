---
name: app-factory-bkit
description: Use when designing, planning, or executing AI-native development workflows that combine App Factory's reproducible module/envelope system with bkit's PDCA, quality gates, automation levels, hook lifecycle, and next-best-move discipline. Triggers for requests about app factory, bkit, PDCA workflows, next best move, agent teams, skill/module lifecycle, context engineering, quality gates, or making work portable across local agents.
---

# App Factory + bkit Workflow

Use this skill to turn vague AI-assisted work into a reproducible workflow with
typed steps, quality gates, explicit automation level, and a concrete next best
move after every response.

## Core Rule

Always end substantial work with:

```text
Next best move: <one concrete action>
Reason: <why this is the highest-leverage next step>
Gate: <scope|quality|security|docs|release>
Automation: <manual|guided|semi_auto|auto>
Risk: <low|medium|high>
```

Keep it short. The recommendation must be actionable, not motivational.

## Mental Model

Combine two systems:

- **App Factory**: module manifests, input/output schemas, envelopes, provenance,
  catalog/registry, hashable workflow steps, learned next-path suggestions.
- **bkit**: PDCA phases, context engineering, quality gates, automation levels,
  hooks, agent teams, audit trail, docs-as-code, skill evals.

The merged pattern:

```text
spec/module -> envelope/provenance -> execute -> quality gate -> next best move
```

## Minimal Workflow

1. **Plan**: identify the smallest useful workflow step and affected surfaces.
2. **Do**: make a scoped, reversible change or produce the requested artifact.
3. **Check**: run the nearest meaningful validation, or state why it could not run.
4. **Act**: update docs/state when useful and choose one next best move.
5. **Report**: summarize outcome, verification, and next best move.

## Recommendation Schema

Use this structure when designing tools, commands, or final recommendations:

```python
NextBestMove(
    action="run_tests|inspect|document|implement|ask|none",
    phase="plan|do|check|act|report",
    gate="scope|quality|security|docs|release|none",
    automation_mode="manual|guided|semi_auto|auto",
    risk="low|medium|high|none",
    command=None,
    path=None,
    reason="...",
    confidence="static_rule|learned_transition|human_preference|none",
)
```

## Phase Guidance

- `plan`: define contract, blast radius, and acceptance criteria.
- `do`: implement the smallest slice that moves the workflow forward.
- `check`: run focused tests, static checks, schema validation, or review.
- `act`: integrate results, persist state, update docs, choose the next slice.
- `report`: give the user only the useful outcome and next move.

## Automation Guidance

- `manual`: ask before acting; use for destructive, high-risk, or ambiguous work.
- `guided`: inspect/read freely, ask before writes or external effects.
- `semi_auto`: run non-destructive commands and scoped edits.
- `auto`: continue only when the task already clearly authorizes the action.

Default to `semi_auto` for targeted tests and scoped code edits. Default to
`guided` for architecture decisions and docs-only planning.

## When More Detail Is Needed

Read only the relevant reference:

- App Factory concepts: `references/app-factory.md`
- bkit concepts: `references/bkit.md`
- Hermes adaptation pattern: `references/hermes-adaptation.md`

## Installation Target

To install this skill on another local machine, copy the entire
`app-factory-bkit/` directory into one of:

```text
~/.codex/skills/app-factory-bkit
~/.hermes/skills/app-factory-bkit
```

Use the Codex path for Codex sessions and the Hermes path for Hermes skill
loading.
